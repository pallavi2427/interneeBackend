module.exports = {
  host: "smtp.gmail.com",
  // secure: true,
  // port: 587,
  auth: {
    user: "pallavi.sisodiya9009@gmail.com",
    pass: "ostjvcjqmxwroffy",
  },
};
