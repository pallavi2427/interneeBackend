// import { CampusController } from "controller/campus.controller";
// import { Express } from "express";

// export function CampusRoutes(app: Express) {
//   app.post("/campus/add", CampusController.postCampus);
// }

import { CampusController } from "controller/campus.controller";
import { Express } from "express";
export function CampusRoutes(app: Express) {
  app.post("/campus", (req, res) => {
    console.log(req, ">>>>>>>>>>>>>>>>>>");
    res.send("POST request to /campus");

    // Your route handling logic goes here
  });
}
